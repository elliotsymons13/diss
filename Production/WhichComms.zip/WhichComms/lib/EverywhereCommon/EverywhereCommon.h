#ifndef EVERYWHERE_COMMON_H
#define EVERYWHERE_COMMON_H

#include <DebugLog.h>
const DebugLogLevel GLOBAL_LOG_LEVEL = DebugLogLevel::LVL_TRACE;//LVL_DEBUG;

void log_bytes(uint8_t* buff, size_t len);
bool equal(uint8_t* buff_a, uint8_t* buff_b, size_t len);


enum class err {
    none,
    timeout_expired, 
    buffer_overflow
};

// TODO move to lower in include heirarchy - should not be needed by library users, abstracted away into internals?
enum class comm {
    mode_invalid = -1,
    mode_duplex = 0,
    mode_rx = 1,
    mode_tx = 2
};

#endif // EVERYWHERE_COMMON_H
